import React from "react";

const GetCurrentLocation = () => {
  const getLocation = () => {
    if (!navigator.geolocation) {
      console.log("Geolocation not supported");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;

        console.log("Latitude:", lat);
        console.log("Longitude:", lon);
      },
      (error) => {
        console.log("Error getting location:", error.message);
      },
    );
  };

  return (
    <div className="h-screen flex flex-col justify-center items-center">
      <button
        onClick={getLocation}
        className="px-6 py-3 bg-black text-white rounded-lg"
      >
        Get Current Location
      </button>
    </div>
  );
};

export default GetCurrentLocation;

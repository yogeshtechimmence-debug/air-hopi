// import { X, Eye, EyeOff } from "lucide-react";
// import { useState } from "react";
// import { useNavigate } from "react-router-dom";

// const Login = ({ isOpen, onClose, onLoginSuccess }) => {
//   const navigate = useNavigate();
//   const [showPassword, setShowPassword] = useState(false);

//   const handleLogin = () => {
//     onLoginSuccess();
//   };

//   if (!isOpen) return null;

//   return (
//     <div className="fixed inset-0 z-50 flex items-center justify-center">
//       {/* Background Overlay */}
//       <div
//         className="absolute inset-0 bg-black/50 backdrop-blur-sm"
//         onClick={onClose}
//       />

//       {/* Modal Box */}
//       <div className="relative bg-white w-full max-w-md rounded-2xl p-6 z-10">
//         {/* Close Button */}
//         <button
//           onClick={onClose}
//           className="absolute top-4 right-4 text-gray-500 hover:text-black"
//         >
//           <X />
//         </button>

//         <h2 className="text-xl font-semibold mb-6">Log in to Air Hopi</h2>

//         {/* Email */}
//         <div className="mb-4">
//           <label className="text-sm font-medium">Email</label>
//           <input
//             type="email"
//             placeholder="Email Address"
//             className="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
//           />
//         </div>

//         {/* Password */}
//         <div className="mb-2">
//           <label className="text-sm font-medium">Password</label>
//           <div className="relative">
//             <input
//               type={showPassword ? "text" : "password"}
//               placeholder="Password"
//               className="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
//             />
//             <button
//               type="button"
//               onClick={() => setShowPassword(!showPassword)}
//               className="absolute right-3 top-3 text-gray-500"
//             >
//               {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
//             </button>
//           </div>
//         </div>

//         <p className="text-sm text-green-700 cursor-pointer mb-4">
//           Forgot Password?
//         </p>

//         {/* Button */}
//         <button
//           onClick={() => {
//             handleLogin();
//             navigate("/");
//           }}
//           className="w-full bg-green-700 text-white py-2 rounded-lg font-medium hover:bg-green-800"
//         >
//           Continue
//         </button>

//         {/* Divider */}
//         <div className="flex items-center my-4">
//           <div className="flex-1 h-px bg-gray-300" />
//           <span className="px-3 text-sm text-gray-500">or</span>
//           <div className="flex-1 h-px bg-gray-300" />
//         </div>

//         {/* Social Login */}
//         {/* <div className="flex justify-center gap-4">
//           <button className="w-10 h-10 border rounded-full flex items-center justify-center">
//             <img src="https://www.svgrepo.com/show/475656/google-color.svg" className="w-5" />
//           </button>
//           <button className="w-10 h-10 border rounded-full flex items-center justify-center">
//             <img src="https://www.svgrepo.com/show/475647/facebook-color.svg" className="w-5" />
//           </button>
//         </div> */}
//       </div>
//     </div>
//   );
// };

// export default Login;


import { X, Eye, EyeOff } from "lucide-react";
import { useState } from "react";

const Login = ({ isOpen, onClose, onLoginSuccess }) => {
  const [showPassword, setShowPassword] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
      />

      <div className="relative bg-white w-full max-w-md rounded-2xl p-6 z-10">
        <button
          onClick={onClose}
          className="absolute top-4 right-4"
        >
          <X />
        </button>

        <h2 className="text-xl font-semibold mb-6">
          Log in to Air Hopi
        </h2>

        <input
          type="email"
          placeholder="Email"
          className="w-full mb-4 px-4 py-2 border rounded-lg"
        />

        <div className="relative mb-4">
          <input
            type={showPassword ? "text" : "password"}
            placeholder="Password"
            className="w-full px-4 py-2 border rounded-lg"
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-3"
          >
            {showPassword ? <EyeOff /> : <Eye />}
          </button>
        </div>

        <button
          onClick={onLoginSuccess}
          className="w-full bg-green-700 text-white py-2 rounded-lg"
        >
          Continue
        </button>
      </div>
    </div>
  );
};

export default Login;

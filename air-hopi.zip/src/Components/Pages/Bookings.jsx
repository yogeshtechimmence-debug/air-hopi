import { MapPin, Calendar } from "lucide-react";
import { useState } from "react";

const Bookings = () => {
  const [activeTab, setActiveTab] = useState("bookings");

  const bookingData = [
    {
      title: "king suiye",
      location: "76 Bushy Close, Milton Keynes, England",
      checkIn: "2026-01-25",
      checkOut: "2026-02-28",
      payment: "Cash",
      image: "https://images.unsplash.com/photo-1566073771259-6a8506099945",
    },
    {
      title: "Room in indore",
      location: "Super Corridor Railway Over Bridge, Indore",
      checkIn: "2026-01-12",
      checkOut: "2026-01-12",
      payment: "CARD",
      image: "https://images.unsplash.com/photo-1566073771259-6a8506099945",
    },
  ];

  const completedData = [
    {
      title: "king suiye",
      location: "76 Bushy Close, Milton Keynes, England",
      checkIn: "2025-12-01",
      checkOut: "2025-12-05",
      payment: "Cash",
      image: "https://images.unsplash.com/photo-1566073771259-6a8506099945",
    },
    {
      title: "Room in indore",
      location: "Indore, Madhya Pradesh",
      checkIn: "2025-11-10",
      checkOut: "2025-11-12",
      payment: "CARD",
      image: "https://images.unsplash.com/photo-1566073771259-6a8506099945",
    },
  ];

  // 👇 Active data selector
  const dataToShow = activeTab === "bookings" ? bookingData : completedData;

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      {/* Tabs */}
      <div className="flex gap-4 mb-8">
        <button
          onClick={() => setActiveTab("bookings")}
          className={`flex-1 py-3 rounded-full font-medium ${
            activeTab === "bookings" ? "bg-green-700 text-white" : "bg-gray-100"
          }`}
        >
          Bookings
        </button>

        <button
          onClick={() => setActiveTab("completed")}
          className={`flex-1 py-3 rounded-full font-medium ${
            activeTab === "completed"
              ? "bg-green-700 text-white"
              : "bg-gray-100"
          }`}
        >
          Completed
        </button>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {dataToShow.map((item, index) => (
          <div key={index} className="bg-white rounded-2xl shadow-md p-5">
            {/* Header */}
            <div className="flex gap-4">
              <img
                src={item.image}
                alt=""
                className="w-16 h-16 rounded-lg object-cover"
              />
              <div>
                <h3 className="font-semibold">{item.title}</h3>
                <p className="text-sm text-gray-500 flex items-center gap-1">
                  <MapPin size={14} />
                  {item.location}
                </p>
              </div>
            </div>

            {/* Info */}
            <div className="grid grid-cols-3 gap-4 mt-4 text-sm">
              <div>
                <p className="text-gray-400">Check in</p>
                <p className="flex items-center gap-1 font-medium">
                  <Calendar size={14} className="text-green-600" />
                  {item.checkIn}
                </p>
              </div>

              <div>
                <p className="text-gray-400">Check out</p>
                <p className="flex items-center gap-1 font-medium">
                  <Calendar size={14} className="text-green-600" />
                  {item.checkOut}
                </p>
              </div>

              <div>
                <p className="text-gray-400">Payment</p>
                <p className="font-medium text-green-700">{item.payment}</p>
              </div>
            </div>

            {/* Button */}
            {activeTab === "bookings" && (
              <div className="mt-5 text-right">
                <button className="px-5 py-2 border border-green-700 text-green-700 rounded-full text-sm hover:bg-green-700 hover:text-white transition">
                  Cancel Booking
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Bookings;

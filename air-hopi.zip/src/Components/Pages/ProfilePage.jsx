import { User, Edit, Lock } from "lucide-react";
import { useState } from "react";

const ProfilePage = () => {
  const [activeTab, setActiveTab] = useState("view");

  const Input = ({ label, value, placeholder, type = "text", readOnly }) => (
    <div>
      <label className="block text-sm mb-1">{label}</label>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        readOnly={readOnly}
        className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-1 focus:ring-green-600"
      />
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* LEFT TABS */}
        <div className="bg-white rounded-xl shadow p-4 space-y-2">
          <button
            onClick={() => setActiveTab("view")}
            className={`w-full flex items-center gap-2 px-4 py-3 rounded-lg ${
              activeTab === "view"
                ? "bg-green-100 text-green-700"
                : "hover:bg-gray-100"
            }`}
          >
            <User size={18} /> View Profile
          </button>

          <button
            onClick={() => setActiveTab("edit")}
            className={`w-full flex items-center gap-2 px-4 py-3 rounded-lg ${
              activeTab === "edit"
                ? "bg-green-100 text-green-700"
                : "hover:bg-gray-100"
            }`}
          >
            <Edit size={18} /> Update Profile
          </button>

          <button
            onClick={() => setActiveTab("password")}
            className={`w-full flex items-center gap-2 px-4 py-3 rounded-lg ${
              activeTab === "password"
                ? "bg-green-100 text-green-700"
                : "hover:bg-gray-100"
            }`}
          >
            <Lock size={18} /> Forget Password
          </button>
        </div>

        {/* RIGHT CONTENT */}
        <div className="md:col-span-3 bg-white rounded-xl shadow p-6">
          {/* VIEW PROFILE */}
          {activeTab === "view" && (
            <>
              <div className="bg-white rounded-2xl shadow p-6">
                {/* Profile Image */}
                <div className="flex justify-center mb-6">
                  <div className="w-28 h-28 rounded-full bg-green-200 flex items-center justify-center text-3xl font-semibold text-green-700">
                    A
                  </div>
                </div>

                {/* Profile Details */}
                <div className="space-y-4">
                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-500">First Name</span>
                    <span className="font-medium">yogesh</span>
                  </div>

                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-500">Last Name</span>
                    <span className="font-medium">vishwakarma</span>
                  </div>

                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-500">Email</span>
                    <span className="font-medium">yash@gmail.com</span>
                  </div>

                  <div className="flex justify-between border-b pb-2">
                    <span className="text-gray-500">Contact</span>
                    <span className="font-medium">1234123412</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-gray-500">Address</span>
                    <span className="font-medium">Indore, MP</span>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* UPDATE PROFILE */}
          {activeTab === "edit" && (
            <form className="space-y-4">
              <Input label="First Name" placeholder="Enter first name" />
              <Input label="Last Name" placeholder="Enter last name" />
              <Input label="Email" placeholder="Enter email" />
              <Input label="Contact" placeholder="Enter contact" />
              <Input label="Address" placeholder="Enter address" />

              <button className="mt-4 bg-green-700 text-white px-6 py-2 rounded-lg">
                Update Profile
              </button>
            </form>
          )}

          {/* FORGET PASSWORD */}
          {activeTab === "password" && (
            <form className="space-y-4 max-w-md">
              <Input label="Current Password" type="password" />
              <Input label="New Password" type="password" />
              <Input label="Confirm Password" type="password" />

              <button className="bg-green-700 text-white px-6 py-2 rounded-lg">
                Change Password
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;

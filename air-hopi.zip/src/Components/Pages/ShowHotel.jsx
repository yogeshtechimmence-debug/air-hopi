import React, { useEffect, useRef, useState } from "react";
import {
  Star,
  Wifi,
  Snowflake,
  Refrigerator,
  ParkingSquare,
  Flame,
  MapPin,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const ShowHotel = () => {
  const navigate = useNavigate();
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth();

  const images = [
    "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
  ];
  const amenities = [
    { icon: <Wifi size={18} />, label: "Wifi" },
    { icon: <ParkingSquare size={18} />, label: "Free parking on premises" },
    { icon: <Snowflake size={18} />, label: "Air Conditioning" },
    { icon: <Flame size={18} />, label: "Fire extinguisher" },
    { icon: <Refrigerator size={18} />, label: "Refrigerator" },
  ];
  const reviews = [
    {
      name: "aa aa",
      date: "Saturday 11:22 AM",
      comment: "nice stay",
      rating: 4,
    },
    {
      name: "bb bb",
      date: "19 Sep 2025 12:07 PM",
      comment: "Provide best service room was osm easy to find silent place",
      rating: 5,
    },
    {
      name: "cc cc",
      date: "19 Sep 2025 9:57 AM",
      comment: "place was nice and clean",
      rating: 4,
    },
  ];
  const bookedRanges = [
    {
      start: new Date(year, month, 5),
      end: new Date(year, month, 10),
    },
  ];

  useEffect(() => {
    const handler = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const dropdownRef = useRef(null);

  const getDaysInMonth = (year, month) => {
    return new Date(year, month + 1, 0).getDate();
  };
  const [open, setOpen] = useState(false);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);

  const daysInMonth = getDaysInMonth(year, month);

  const handleDateClick = (day) => {
    if (isBooked(day)) return;

    const selectedDate = new Date(year, month, day);

    // First click OR reset
    if (!startDate || (startDate && endDate)) {
      setStartDate(selectedDate);
      setEndDate(null);
      return;
    }

    // Second click (end date)
    if (selectedDate >= startDate) {
      if (isRangeBlocked(startDate, selectedDate)) {
        alert("Selected range contains booked dates");
        return;
      }

      setEndDate(selectedDate);
    } else {
      setStartDate(selectedDate);
    }
  };

  const isBooked = (day) => {
    const date = new Date(year, month, day);

    return bookedRanges.some(
      (range) => date >= range.start && date <= range.end,
    );
  };

  const isRangeBlocked = (start, end) => {
    const current = new Date(start);

    while (current <= end) {
      const day = current.getDate();

      if (isBooked(day)) {
        return true;
      }

      current.setDate(current.getDate() + 1);
    }

    return false;
  };

  const isInRange = (day) => {
    if (!startDate || !endDate) return false;
    const date = new Date(year, month, day);
    return date > startDate && date < endDate;
  };

  const formatDate = (date) => {
    if (!date) return "Add date";
    return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
  };

  const totalDays =
    startDate && endDate
      ? Math.round((endDate - startDate) / (1000 * 60 * 60 * 24)) + 1
      : 0;

  return (
    <div>
      {" "}
      <div className="w-full max-w-6xl mx-auto px-4">
        {/* Title */}
        <h1 className="text-2xl pt-3 font-semibold mb-4">
          Mar Azul 1bhk in Candolim
        </h1>

        {/* Gallery */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 rounded-2xl overflow-hidden">
          {/* Left big image */}
          <div className="h-[420px]">
            <img
              src={images[0]}
              alt=""
              className="w-full h-full object-cover"
            />
          </div>

          {/* Right grid */}
          <div className="grid grid-cols-2 gap-2 relative">
            {images.slice(1).map((img, index) => (
              <div key={index} className="h-[209px]">
                <img src={img} alt="" className="w-full h-full object-cover" />
              </div>
            ))}

            {/* Show all photos button */}
            <button className="absolute bottom-4 right-4 bg-white text-sm font-medium px-4 py-2 rounded-lg shadow flex items-center gap-2">
              <span className="grid grid-cols-3 gap-[2px]">
                <span className="w-1.5 h-1.5 bg-black rounded-sm" />
                <span className="w-1.5 h-1.5 bg-black rounded-sm" />
                <span className="w-1.5 h-1.5 bg-black rounded-sm" />
                <span className="w-1.5 h-1.5 bg-black rounded-sm" />
                <span className="w-1.5 h-1.5 bg-black rounded-sm" />
                <span className="w-1.5 h-1.5 bg-black rounded-sm" />
              </span>
              Show all photos
            </button>
          </div>
        </div>

        <div>
          <div className="max-w-7xl mx-auto px-6 py-10 grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* LEFT */}
            <div className="lg:col-span-2">
              {/* Rating */}
              <div className="border rounded-xl shadow-sm p-6 mb-6 flex justify-between items-center">
                <div className="text-center">
                  <p className="text-lg font-semibold">0.0</p>
                  <div className="flex gap-1 justify-center text-green-600">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} size={14} />
                    ))}
                  </div>
                </div>

                <div className="text-center">
                  <Star className="mx-auto mb-1" />
                  <p className="text-sm">Highly Rated</p>
                </div>

                <div className="text-center">
                  <p className="text-lg font-semibold">0</p>
                  <p className="text-sm">Reviews</p>
                </div>
              </div>

              {/* Host */}
              <div className="border-b pb-6 mb-6 flex gap-4">
                <img
                  src="https://via.placeholder.com/48"
                  className="h-12 w-12 rounded-full"
                />
                <div>
                  <p className="font-semibold">Hosted By Yogesh Vishwakarma</p>
                  <p className="text-sm text-gray-500">
                    Hosting since 4 months
                  </p>
                </div>
              </div>

              {/* Amenities */}
              <h3 className="text-xl font-semibold mb-4">
                What this place offers
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {amenities.map((item, index) => (
                  <div key={index} className="flex items-center gap-3">
                    {item.icon}
                    <span>{item.label}</span>
                  </div>
                ))}
              </div>

              <button className="mt-6 bg-gray-200 px-6 py-3 rounded-lg text-sm">
                Show all amenities
              </button>
            </div>

            {/* RIGHT */}
            <div className="lg:col-span-1">
              <div className=" border rounded-2xl shadow-lg p-6">
                <div className="mb-4">
                  <span className="text-gray-400 line-through mr-2">5000</span>
                  <span className="text-2xl font-semibold">5000</span>
                  <span className="text-gray-500 ml-1">For 1 Month</span>
                </div>

                <div className="border rounded-lg overflow-hidden mb-4">
                  <div
                    onClick={() => setOpen(true)}
                    className="grid grid-cols-2 text-sm cursor-pointer"
                  >
                    <div className="p-3 border-r">
                      <p className="text-gray-500">Check-in</p>
                      <p className="font-medium">
                        {startDate ? formatDate(startDate) : "Add date"}
                      </p>
                    </div>

                    <div className="p-3">
                      <p className="text-gray-500">Check-out</p>
                      <p className="font-medium">
                        {endDate ? formatDate(endDate) : "Add date"}
                      </p>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => {
                    navigate("/confirmation");
                  }}
                  className="w-full bg-green-700 hover:bg-green-800 text-white py-3 rounded-lg font-semibold"
                >
                  Reserve
                </button>
              </div>
            </div>

            {open && (
              <div
                style={{ marginLeft: "650px" }}
                ref={dropdownRef}
                className="absolute mt-5 ml-96 left-0 bg-white rounded-2xl shadow-xl p-4 z-50 w-[280px]"
              >
                <p className="font-semibold mb-3">
                  {today.toLocaleString("default", { month: "long" })} {year}
                </p>

                <div className="grid grid-cols-7 gap-2 text-center">
                  {Array.from({ length: daysInMonth }, (_, i) => {
                    const day = i + 1;
                    const isStart = startDate && startDate.getDate() === day;
                    const isEnd = endDate && endDate.getDate() === day;

                    return (
                      <button
                        key={day}
                        disabled={isBooked(day)}
                        onClick={() => handleDateClick(day)}
                        className={`h-9 rounded-full text-sm
                           ${
                             isBooked(day)
                               ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                               : isStart || isEnd
                                 ? "bg-blue-600 text-white"
                                 : isInRange(day)
                                   ? "bg-blue-100 text-blue-700"
                                   : "hover:bg-gray-100"
                           }
                        `}
                      >
                        {day}
                      </button>
                    );
                  })}
                </div>

                {/* Footer */}
                {totalDays > 0 && (
                  <p className="text-sm mt-3 text-gray-700">
                    Total days: <b>{totalDays}</b>
                  </p>
                )}

                <button
                  onClick={() => setOpen(false)}
                  className="mt-3 text-sm text-blue-500"
                >
                  Done
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="max-w-6xl mx-auto px-4">
          {/* Heading */}
          <div className="text-center mb-8">
            <div className="flex justify-center items-center gap-2 text-3xl font-semibold">
              4.3
            </div>
            <h2 className="text-xl font-semibold mt-2">Guest Reviews</h2>
            <p className="text-gray-500 text-sm mt-1">
              This home is a highly rated based on ratings,reviews
            </p>
          </div>

          {/* Reviews */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {reviews.map((item, index) => (
              <div
                key={index}
                className="border rounded-xl p-5 bg-white shadow-sm"
              >
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-12 h-12 rounded-full bg-green-300 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium">{item.name}</h4>
                    <div className="flex items-center gap-1">
                      {[...Array(item.rating)].map((_, i) => (
                        <Star
                          key={i}
                          size={14}
                          className="fill-green-600 text-green-600"
                        />
                      ))}
                    </div>
                  </div>
                  <span className="ml-auto text-xs text-gray-400">
                    {item.date}
                  </span>
                </div>

                <p className="text-sm text-gray-700">{item.comment}</p>
              </div>
            ))}
          </div>

          {/* Show all reviews */}
          <button className="w-full mt-8 py-3 bg-gray-200 rounded-lg text-sm font-medium">
            Show all reviews
          </button>

          {/* Location */}
          <div className="mt-10 border-t pt-6 pb-4">
            <h3 className="font-semibold mb-2">See Location on Map</h3>
            <p className="flex items-center gap-2 text-gray-600 text-sm">
              <MapPin size={16} />
              Super Corridor Railway Over Bridge, Indore, Madhya Pradesh
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShowHotel;

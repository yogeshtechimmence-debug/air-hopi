import { Search, MapPin, Minus, Plus, Bell } from "lucide-react";
import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

const locations = [
  "Delhi, India",
  "Mumbai, India",
  "Bangalore, India",
  "Indore, India",
  "Jaipur, India",
  "Goa, India",
  "Pune, India",
];

const hotels = [
  {
    id: 1,
    name: "Sayaji Hotel Indore",
    price: 4500,
    lat: 22.752016,
    lng: 75.890559,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.8,
  },
  {
    id: 2,
    name: "Radisson Blu Indore",
    price: 5500,
    lat: 22.7502,
    lng: 75.90319,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.9,
  },
  {
    id: 3,
    name: "Lemon Tree Hotel Indore",
    price: 4000,
    lat: 22.7198,
    lng: 75.8453,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.7,
  },
  {
    id: 4,
    name: "Sarovar Portico Indore",
    price: 4200,
    lat: 22.7232,
    lng: 75.8432,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.6,
  },
  {
    id: 5,
    name: "Shreemaya Hotel",
    price: 3000,
    lat: 22.7207,
    lng: 75.8461,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.5,
  },
  {
    id: 6,
    name: "Hotel Infiniti Indore",
    price: 2800,
    lat: 22.75334,
    lng: 75.90341,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.4,
  },
  {
    id: 7,
    name: "Hotel Crown Palace",
    price: 2500,
    lat: 22.7183,
    lng: 75.8487,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.3,
  },
  {
    id: 8,
    name: "Hotel Winway Indore",
    price: 3200,
    lat: 22.719,
    lng: 75.844,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.4,
  },
  {
    id: 9,
    name: "Hotel Apna Avenue",
    price: 3500,
    lat: 22.7484,
    lng: 75.8986,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.5,
  },
  {
    id: 7,
    name: "Hotel Crown Palace",
    price: 2500,
    lat: 22.7183,
    lng: 75.8487,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.3,
  },
  {
    id: 8,
    name: "Hotel Winway Indore",
    price: 3200,
    lat: 22.719,
    lng: 75.844,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.4,
  },
  {
    id: 9,
    name: "Hotel Apna Avenue",
    price: 3500,
    lat: 22.7484,
    lng: 75.8986,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.5,
  },
];

const HomePage = () => {
  const navigate = useNavigate();

  const [whereOpen, setWhereOpen] = useState(false);
  const [whereValue, setWhereValue] = useState("");
  const dropdownRef = useRef(null);

  // close dropdown on outside click
  useEffect(() => {
    const handler = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setWhereOpen(false);
        setOpen(false);
        Setselectoropen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const filteredLocations = locations.filter((loc) =>
    loc.toLowerCase().includes(whereValue.toLowerCase()),
  );

  const getDaysInMonth = (year, month) => {
    return new Date(year, month + 1, 0).getDate();
  };

  //   ----------------------------------------------------------------------------------------------------
  const [open, setOpen] = useState(false);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);

  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth();
  const daysInMonth = getDaysInMonth(year, month);

  const handleDateClick = (day) => {
    const selectedDate = new Date(year, month, day);

    if (!startDate || (startDate && endDate)) {
      setStartDate(selectedDate);
      setEndDate(null);
    } else if (selectedDate >= startDate) {
      setEndDate(selectedDate);
    } else {
      setStartDate(selectedDate);
    }
  };

  const isInRange = (day) => {
    if (!startDate || !endDate) return false;
    const date = new Date(year, month, day);
    return date > startDate && date < endDate;
  };

  const totalDays =
    startDate && endDate
      ? Math.round((endDate - startDate) / (1000 * 60 * 60 * 24)) + 1
      : 0;

  //   ------------------------------------------------------------------------------------------------
  const [selectoropen, Setselectoropen] = useState(false);

  const [guests, setGuests] = useState({
    adults: 0,
    children: 0,
    infants: 0,
    pets: 0,
  });

  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) {
        Setselectoropen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const updateCount = (type, value) => {
    setGuests((prev) => ({
      ...prev,
      [type]: Math.max(0, prev[type] + value),
    }));
  };

  const summary = () => {
    const totalGuests = guests.adults + guests.children;
    let text = "";

    if (totalGuests > 0) text += `${totalGuests} Guests`;
    if (guests.infants > 0) text += ` · ${guests.infants} Infants`;
    if (guests.pets > 0) text += ` · ${guests.pets} Pets`;

    return text || "Add guests";
  };
  const Row = ({ label, sub, type }) => (
    <div className="flex items-center justify-between py-3">
      <div>
        <p className="font-medium">{label}</p>
        {sub && <p className="text-xs text-gray-500">{sub}</p>}
      </div>

      <div className="flex items-center gap-3">
        <button
          disabled={guests[type] === 0}
          onClick={() => updateCount(type, -1)}
          className="h-8 w-8 rounded-full border flex items-center justify-center disabled:opacity-40"
        >
          <Minus size={14} />
        </button>

        <span className="w-4 text-center">{guests[type]}</span>

        <button
          onClick={() => updateCount(type, 1)}
          className="h-8 w-8 rounded-full border flex items-center justify-center"
        >
          <Plus size={14} />
        </button>
      </div>
    </div>
  );

  //   ------------------------------------------------------------------------------------------------

  const handleSearch = () => {
    console.log("WHERE:", whereValue);

    console.log("WHEN:", {
      startDate,
      endDate,
      totalDays,
    });

    console.log("WHO:", {
      adults: guests.adults,
      children: guests.children,
      infants: guests.infants,
      pets: guests.pets,
    });
    navigate("/location");

    // const resetAll = () => {
    //   setWhereValue("");
    //   setStartDate(null);
    //   setEndDate(null);
    //   setGuests({
    //     adults: 0,
    //     children: 0,
    //     infants: 0,
    //     pets: 0,
    //   });
    // };
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="min-h-screen bg-gray-100  items-start justify-center pt-10">
        <div className="w-full flex justify-center">
          <div className="relative flex items-center bg-white shadow-lg rounded-full px-2 py-2 w-full max-w-4xl border">
            {/* WHERE */}
            <div
              className="flex-1 px-4 cursor-pointer"
              onClick={() => setWhereOpen(true)}
            >
              <p className="text-xs font-semibold text-gray-800">Where</p>
              <input
                value={whereValue}
                readOnly
                placeholder="Search destinations"
                className="w-full text-sm text-gray-500 focus:outline-none cursor-pointer"
              />
            </div>

            <div className="h-8 w-px bg-gray-300" />

            {/* WHEN */}
            <div className="flex-1 px-4">
              <p className="text-xs font-semibold text-gray-800">When</p>
              <input
                readOnly
                onClick={() => setOpen(true)}
                value={
                  startDate && endDate
                    ? `${startDate.getDate()} - ${endDate.getDate()}`
                    : ""
                }
                placeholder="Add dates"
                className="w-full text-sm text-gray-500 focus:outline-none cursor-pointer"
              />
            </div>

            <div className="h-8 w-px bg-gray-300" />

            {/* WHO */}
            <div className="flex-1 px-4">
              <p className="text-xs font-semibold text-gray-800">Who</p>
              <input
                readOnly
                onClick={() => Setselectoropen(true)}
                value={summary()}
                className="w-full text-sm text-gray-500 focus:outline-none cursor-pointer"
              />
            </div>

            {/* SEARCH BUTTON */}
            <button
              onClick={handleSearch}
              className="bg-rose-500 hover:bg-rose-600 text-white p-3 rounded-full ml-2"
            >
              <Search size={18} />
            </button>

            {/* location */}
            {whereOpen && (
              <div
                ref={dropdownRef}
                className="absolute left-0 top-20 bg-white w-[280px] rounded-2xl shadow-xl p-4 border z-50"
              >
                {/* Search input */}
                <input
                  autoFocus
                  value={whereValue}
                  onChange={(e) => setWhereValue(e.target.value)}
                  placeholder="Search destinations"
                  className="w-full border rounded-lg px-3 py-2 mb-3 text-sm focus:outline-none focus:ring-2 focus:ring-rose-400"
                />

                {/* Locations list */}
                <div className="max-h-60 overflow-y-auto">
                  {filteredLocations.map((loc, index) => (
                    <div
                      key={index}
                      onClick={() => {
                        setWhereValue(loc);
                        setWhereOpen(false);
                      }}
                      className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-100 cursor-pointer"
                    >
                      <MapPin size={16} className="text-gray-500" />
                      <span className="text-sm text-gray-700">{loc}</span>
                    </div>
                  ))}

                  {filteredLocations.length === 0 && (
                    <p className="text-sm text-gray-400 px-3 py-2">
                      No locations found
                    </p>
                  )}
                </div>

                <button
                  onClick={() => setWhereOpen(false)}
                  className="mt-3 text-sm text-rose-500"
                >
                  Close
                </button>
              </div>
            )}

            {/* Calendar */}
            {open && (
              <div
                ref={dropdownRef}
                className="absolute ml-72 top-24 left-0 bg-white rounded-2xl shadow-xl p-4 z-50 w-[280px]"
              >
                <p className="font-semibold mb-3">
                  {today.toLocaleString("default", { month: "long" })} {year}
                </p>

                <div className="grid grid-cols-7 gap-2 text-center">
                  {Array.from({ length: daysInMonth }, (_, i) => {
                    const day = i + 1;
                    const isStart = startDate && startDate.getDate() === day;
                    const isEnd = endDate && endDate.getDate() === day;

                    return (
                      <button
                        key={day}
                        onClick={() => handleDateClick(day)}
                        className={`h-9 rounded-full text-sm
                    ${
                      isStart || isEnd
                        ? "bg-blue-600 text-white"
                        : isInRange(day)
                          ? "bg-blue-100 text-blue-700"
                          : "hover:bg-gray-100"
                    }
                  `}
                      >
                        {day}
                      </button>
                    );
                  })}
                </div>

                {/* Footer */}
                {totalDays > 0 && (
                  <p className="text-sm mt-3 text-gray-700">
                    Total days: <b>{totalDays}</b>
                  </p>
                )}

                <button
                  onClick={() => setOpen(false)}
                  className="mt-3 text-sm text-rose-500"
                >
                  Close
                </button>
              </div>
            )}

            {/* selector */}
            {selectoropen && (
              <div
                ref={dropdownRef}
                className="absolute top-24 right-0 w-[310px] bg-white rounded-2xl shadow-xl p-4 z-50"
              >
                <Row label="Adults" sub="Ages 13+" type="adults" />
                <Row label="Children" sub="Ages 2–12" type="children" />
                <Row label="Infants" sub="Under 2" type="infants" />
                <Row
                  label="Pets"
                  sub="Bringing a service animal?"
                  type="pets"
                />

                <div className="flex justify-end mt-4">
                  <button
                    onClick={() => Setselectoropen(false)}
                    className="mt-3 text-sm text-rose-500"
                  >
                    Close
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
        <div className="p-6 space-y-6">
          <h2 className="text-xl font-semibold">
            Over {hotels.length}+ homes within map area
          </h2>

          <div
            className="
               grid gap-6
               grid-cols-1
               sm:grid-cols-2
               md:grid-cols-3
               lg:grid-cols-4
               xl:grid-cols-6
               2xl:grid-cols-8
             "
          >
            {hotels.map((hotel) => (
              <div
                key={hotel.id}
                onClick={() => navigate("/showhotel")}
                className="cursor-pointer group"
              >
                {/* IMAGE */}
                <div className="relative overflow-hidden rounded-xl">
                  <img
                    src={hotel.image}
                    className="h-52 w-full object-cover group-hover:scale-105 transition"
                    alt={hotel.name}
                  />

                  <button className="absolute top-3 right-3 bg-white p-2 rounded-full shadow">
                    ❤️
                  </button>
                </div>

                <div className="mt-2 space-y-1">
                  <div className="flex justify-between">
                    <h3 className="font-medium truncate">{hotel.name}</h3>
                    <span className="text-sm">⭐ {hotel.rating}</span>
                  </div>

                  <p className="text-gray-500 text-sm">1 bedroom · 1 bed</p>

                  <p className="font-semibold">
                    ₹{hotel.price.toLocaleString()}
                    <span className="font-normal text-gray-500">
                      {" "}
                      / 3 nights
                    </span>
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;

// import { X } from "lucide-react";

// const SignUp = ({ isOpen, onClose }) => {
//   if (!isOpen) return null;

//   return (
//     <div className="fixed inset-0 z-50 flex items-center justify-center">
//       {/* Background Overlay */}
//       <div
//         className="absolute inset-0 bg-black/60 backdrop-blur-sm"
//         onClick={onClose}
//       />

//       {/* Modal */}
//       <div className="relative bg-white w-full max-w-xl rounded-2xl p-6 z-50 max-h-[90vh] overflow-y-auto">
//         {/* Header */}
//         <div className="flex justify-between items-center mb-4">
//           <h2 className="text-2xl font-semibold">Sign Up</h2>
//           <button onClick={onClose}>
//             <X />
//           </button>
//         </div>

//         {/* Form */}
//         <div className="space-y-4">
//           <div className="grid grid-cols-2 gap-3">
//             <input
//               type="text"
//               placeholder="First Name"
//               className="border rounded-lg px-3 py-2 w-full"
//             />
//             <input
//               type="text"
//               placeholder="Surname"
//               className="border rounded-lg px-3 py-2 w-full"
//             />
//           </div>

//           <div className="grid grid-cols-2 gap-3">
//             <input
//               type="date"
//               className="border rounded-lg px-3 py-2 w-full"
//             />
//             <input
//               type="number"
//               placeholder="Contact Number"
//               className="border rounded-lg px-3 py-2 w-full"
//             />
//           </div>

//           <button className="w-full border rounded-lg py-2 text-green-700 hover:bg-green-50">
//             Upload Profile Photo
//           </button>

//           <input
//             type="email"
//             placeholder="Email Address"
//             className="border rounded-lg px-3 py-2 w-full"
//           />

//           <input
//             type="text"
//             placeholder="Location"
//             className="border rounded-lg px-3 py-2 w-full"
//           />

//           <input
//             type="password"
//             placeholder="Password"
//             className="border rounded-lg px-3 py-2 w-full"
//           />

//           <button className="w-full bg-green-700 text-white py-2 rounded-lg hover:bg-green-800">
//             Create Account
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SignUp;



import { X } from "lucide-react";

const SignUp = ({ isOpen, onClose, openLogin }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div
        className="absolute inset-0 bg-black/60"
        onClick={onClose}
      />

      <div className="relative bg-white w-full max-w-xl rounded-2xl p-6 z-50">
        <button
          onClick={onClose}
          className="absolute top-4 right-4"
        >
          <X />
        </button>

        <h2 className="text-2xl font-semibold mb-4">Sign Up</h2>

        <div className="space-y-4">
          <input className="border p-2 w-full" placeholder="First Name" />
          <input className="border p-2 w-full" placeholder="Last Name" />
          <input className="border p-2 w-full" placeholder="Email" />
          <input className="border p-2 w-full" placeholder="Password" />

          <button
            onClick={() => {
              onClose();    
              openLogin();  
            }}
            className="w-full bg-green-700 text-white py-2 rounded-lg"
          >
            Create Account
          </button>
        </div>
      </div>
    </div>
  );
};

export default SignUp;

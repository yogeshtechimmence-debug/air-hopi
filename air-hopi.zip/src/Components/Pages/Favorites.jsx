import React from "react";
import { Heart, MapPin, Star } from "lucide-react";
const Favorites = () => {
  const favorites = [
    {
      id: 1,
      title: "Room in indore",
      location: "Super Corridor Railway Over Bridge, Indore",
      price: 2999,
      rating: 4.3,
      image: "https://images.unsplash.com/photo-1505691938895-1758d7feb511",
    },
  ];
  return (
    <div>
      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Heading */}
        <div className="text-center mb-12">
          <h1 className="text-3xl font-semibold">Your Favorites</h1>
          <p className="text-gray-500 mt-2">
            Save time, stay where your heart feels at home.
          </p>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {favorites.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl shadow-md hover:shadow-lg transition"
            >
              {/* Image */}
              <div className="relative">
                <img
                  src={item.image}
                  alt=""
                  className="w-full h-44 object-cover rounded-t-2xl"
                />

                {/* Heart */}
                <button className="absolute top-3 right-3 bg-white p-2 rounded-full shadow">
                  <Heart size={18} className="text-red-500 fill-red-500" />
                </button>
              </div>

              {/* Content */}
              <div className="p-4">
                <h3 className="font-semibold text-sm">{item.title}</h3>

                <p className="text-xs text-gray-500 flex items-center gap-1 mt-1">
                  <MapPin size={12} />
                  {item.location}
                </p>

                <div className="flex justify-between items-center mt-3">
                  <p className="text-green-700 font-semibold text-sm">
                    ₹{item.price}
                    <span className="text-gray-500 font-normal"> / night</span>
                  </p>

                  <div className="flex items-center gap-1 text-sm">
                    <Star
                      size={14}
                      className="text-yellow-400 fill-yellow-400"
                    />
                    {item.rating}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Favorites;

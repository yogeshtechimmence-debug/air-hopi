// import {
//   Heart,
//   Bell,
//   Logs,
//   User,
//   Book,
//   Phone,
//   LogOut,
//   BookAudioIcon,
// } from "lucide-react";
// import { useState, useRef, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import Login from "./Login";
// import SignUp from "./SignUp";

// const Navbar = () => {
//   const [isLoggedIn, setIsLoggedIn] = useState(false);
//   const [open, setOpen] = useState(false);
//   const [loginOpen, setLoginOpen] = useState(false);
//   const [signupOpen, setSignupOpen] = useState(false);
//   const dropdownRef = useRef(null);
//   const navigate = useNavigate();

//   useEffect(() => {
//     const handleClickOutside = (e) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
//         setOpen(false);
//       }
//     };
//     document.addEventListener("mousedown", handleClickOutside);
//     return () => document.removeEventListener("mousedown", handleClickOutside);
//   }, []);

//   return (
//     <>
//       <nav className="w-full border-b bg-white">
//         <div className="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between">
//           {/* Logo */}
//           <img
//             src="https://i.ibb.co/xK6qDh8K/4b833c47-7c52-41ec-94f0-aab24a2c65a2.jpg"
//             alt="Logo"
//             className="h-10 cursor-pointer"
//             onClick={() => navigate("/")}
//           />

//           {/* Right Icons */}
//           <div className="relative" ref={dropdownRef}>
//             <div className="flex items-center gap-3">
//               {!isLoggedIn ? (
//                 <>
//                   {/* Login */}
//                   <button
//                     onClick={() => setLoginOpen(true)}
//                     className="px-4 border py-2 text-sm font-medium rounded-full hover:bg-gray-200"
//                   >
//                     Login
//                   </button>

//                   {/* Signup */}
//                   <button
//                     onClick={() => setSignupOpen(true)}
//                     className="px-4 border py-2 text-sm font-medium rounded-full hover:bg-gray-200"
//                   >
//                     Sign Up
//                   </button>
//                 </>
//               ) : (
//                 /* Menu Icon only after login */
//                 <button
//                   onClick={() => setOpen(!open)}
//                   className="p-2 border rounded-full hover:bg-gray-200"
//                 >
//                   <Logs size={22} />
//                 </button>
//               )}
//             </div>

//             {/* Dropdown */}
//             {open && (
//               <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border z-50">
//                 <ul className="py-2 text-sm">
//                   <li
//                     onClick={() => navigate("/profile")}
//                     className="px-4 py-2 flex items-center gap-2 hover:bg-gray-100 cursor-pointer"
//                   >
//                     <User size={16} /> Profile
//                   </li>

//                   <li
//                     onClick={() => navigate("/booking")}
//                     className="px-4 py-2 flex items-center gap-2 hover:bg-gray-100 cursor-pointer"
//                   >
//                     <Book size={16} /> My Booking
//                   </li>

//                   <li
//                     onClick={() => navigate("/myfavorites")}
//                     className="px-4 py-2 flex items-center gap-2 hover:bg-gray-100 cursor-pointer"
//                   >
//                     <Heart size={16} /> My Favourite
//                   </li>

//                   <li
//                     onClick={() => navigate("/support")}
//                     className="px-4 py-2 flex items-center gap-2 hover:bg-gray-100 cursor-pointer"
//                   >
//                     <Phone size={16} /> Contact Support
//                   </li>

//                   <li
//                     onClick={() => navigate("/about")}
//                     className="px-4 py-2 flex items-center gap-2 hover:bg-gray-100 cursor-pointer"
//                   >
//                     <BookAudioIcon size={16} /> About Us
//                   </li>
//                   <hr className="my-1" />

//                   <li
//                     onClick={() => {
//                       setIsLoggedIn(false);
//                       setOpen(false);
//                       navigate("/");
//                     }}
//                     className="px-4 py-2 flex items-center gap-2 text-red-600 hover:bg-gray-100 cursor-pointer"
//                   >
//                     <LogOut size={16} /> Logout
//                   </li>
//                 </ul>
//               </div>
//             )}
//           </div>
//         </div>
//       </nav>
//       <Login
//         isOpen={loginOpen}
//         onClose={() => setLoginOpen(false)}
//         onLoginSuccess={() => {
//           setIsLoggedIn(true);
//           setLoginOpen(false);
//         }}
        
//       />
//       <SignUp isOpen={signupOpen} onClose={() => setSignupOpen(false)} />
//     </>
//   );
// };

// export default Navbar;


import {
  Heart,
  Logs,
  User,
  Book,
  Phone,
  LogOut,
  BookAudioIcon,
} from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Login from "./Login";
import SignUp from "./SignUp";

const Navbar = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [signupOpen, setSignupOpen] = useState(false);

  const dropdownRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <>
      <nav className="w-full border-b bg-white">
        <div className="max-w-7xl mx-auto px-4 py-2 flex justify-between items-center">
          {/* Logo */}
          <img
            src="https://i.ibb.co/xK6qDh8K/4b833c47-7c52-41ec-94f0-aab24a2c65a2.jpg"
            alt="Logo"
            className="h-10 cursor-pointer"
            onClick={() => navigate("/")}
          />

          {/* Right Side */}
          <div className="relative" ref={dropdownRef}>
            {!isLoggedIn ? (
              <div className="flex gap-3">
                <button
                  onClick={() => setLoginOpen(true)}
                  className="px-4 py-2 border rounded-full text-sm"
                >
                  Login
                </button>

                <button
                  onClick={() => setSignupOpen(true)}
                  className="px-4 py-2 border rounded-full text-sm"
                >
                  Sign Up
                </button>
              </div>
            ) : (
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="p-2 border rounded-full"
              >
                <Logs size={22} />
              </button>
            )}

            {/* Dropdown */}
            {menuOpen && isLoggedIn && (
              <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border z-50">
                <ul className="py-2 text-sm">
                  <li
                    onClick={() => navigate("/profile")}
                    className="px-4 py-2 flex gap-2 hover:bg-gray-100 cursor-pointer"
                  >
                    <User size={16} /> Profile
                  </li>

                  <li
                    onClick={() => navigate("/booking")}
                    className="px-4 py-2 flex gap-2 hover:bg-gray-100 cursor-pointer"
                  >
                    <Book size={16} /> My Booking
                  </li>

                  <li
                    onClick={() => navigate("/myfavorites")}
                    className="px-4 py-2 flex gap-2 hover:bg-gray-100 cursor-pointer"
                  >
                    <Heart size={16} /> My Favourite
                  </li>

                  <li
                    onClick={() => navigate("/support")}
                    className="px-4 py-2 flex gap-2 hover:bg-gray-100 cursor-pointer"
                  >
                    <Phone size={16} /> Contact Support
                  </li>

                  <li
                    onClick={() => navigate("/about")}
                    className="px-4 py-2 flex gap-2 hover:bg-gray-100 cursor-pointer"
                  >
                    <BookAudioIcon size={16} /> About Us
                  </li>

                  <hr />

                  <li
                    onClick={() => {
                      setIsLoggedIn(false);
                      setMenuOpen(false);
                      navigate("/");
                    }}
                    className="px-4 py-2 flex gap-2 text-red-600 hover:bg-gray-100 cursor-pointer"
                  >
                    <LogOut size={16} /> Logout
                  </li>
                </ul>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Login Modal */}
      <Login
        isOpen={loginOpen}
        onClose={() => setLoginOpen(false)}
        onLoginSuccess={() => {
          setIsLoggedIn(true);
          setLoginOpen(false);
        }}
      />

      {/* Signup Modal */}
      <SignUp
        isOpen={signupOpen}
        onClose={() => setSignupOpen(false)}
        openLogin={() => setLoginOpen(true)}
      />
    </>
  );
};

export default Navbar;

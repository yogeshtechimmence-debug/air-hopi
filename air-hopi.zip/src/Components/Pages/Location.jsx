import React, { useMemo, useState } from "react";
import { GoogleMap, OverlayView, useLoadScript } from "@react-google-maps/api";
import { useNavigate } from "react-router-dom";

const hotels = [
  {
    id: 1,
    name: "Sayaji Hotel Indore",
    price: 4500,
    lat: 22.752016,
    lng: 75.890559,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.8,
  },
  {
    id: 2,
    name: "Radisson Blu Indore",
    price: 5500,
    lat: 22.7502,
    lng: 75.90319,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.9,
  },
  {
    id: 3,
    name: "Lemon Tree Hotel Indore",
    price: 4000,
    lat: 22.7198,
    lng: 75.8453,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.7,
  },
  {
    id: 4,
    name: "Sarovar Portico Indore",
    price: 4200,
    lat: 22.7232,
    lng: 75.8432,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.6,
  },
  {
    id: 5,
    name: "Shreemaya Hotel",
    price: 3000,
    lat: 22.7207,
    lng: 75.8461,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.5,
  },
  {
    id: 6,
    name: "Hotel Infiniti Indore",
    price: 2800,
    lat: 22.75334,
    lng: 75.90341,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.4,
  },
  {
    id: 7,
    name: "Hotel Crown Palace",
    price: 2500,
    lat: 22.7183,
    lng: 75.8487,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.3,
  },
  {
    id: 8,
    name: "Hotel Winway Indore",
    price: 3200,
    lat: 22.719,
    lng: 75.844,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.4,
  },
  {
    id: 9,
    name: "Hotel Apna Avenue",
    price: 3500,
    lat: 22.7484,
    lng: 75.8986,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.5,
  },
  {
    id: 10,
    name: "Hotel Essentia Indore",
    price: 2700,
    lat: 22.7015,
    lng: 75.8791,
    image:
      "https://i.ibb.co/XZ9YRRkj/5a28e836-8eb5-473f-aacb-1f152cc66ed7.avif",
    rating: 4.2,
  },
];

const Location = () => {
  const Navigate = useNavigate()
  const [selectedHotel, setSelectedHotel] = useState(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [tilesLoaded, setTilesLoaded] = useState(false);

  const { isLoaded } = useLoadScript({
    googleMapsApiKey: "AIzaSyAN3Lz2pT2ItRTkQ1MHCwHynGjmpDHhnt8",
  });

  const mapCenter = useMemo(() => ({ lat: 22.7179, lng: 75.8333 }), []);

  const handlePriceClick = (e, hotel) => {
    e.stopPropagation();
    e.preventDefault();

    setSelectedHotel((prev) => (prev?.id === hotel.id ? null : hotel));
  };

  return (
    <div className="h-screen flex">
      <div className="w-[60%] overflow-y-scroll p-6 space-y-6">
        <h2 className="text-xl font-semibold">
          Over {hotels.length}+ homes within map area
        </h2>

        <div className="grid grid-cols-3 gap-6">
          {hotels.map((hotel) => (
            <div
              key={hotel.id}
              // onMouseEnter={() => setSelectedHotel(hotel.id)}
              // onMouseLeave={() => setSelectedHotel(null)}
              className="cursor-pointer group"
            >
              {/* IMAGE */}
              <div className="relative overflow-hidden rounded-xl">
                <img
                  src={hotel.image}
                  className="h-52 w-full object-cover group-hover:scale-105 transition"
                />

                <button className="absolute top-3 right-3 bg-white p-2 rounded-full shadow">
                  ❤️
                </button>
              </div>

              <div className="mt-2 space-y-1">
                <div className="flex justify-between">
                  <h3 className="font-medium">{hotel.name}</h3>
                  <span className="text-sm">⭐ {hotel.rating}</span>
                </div>

                <p className="text-gray-500 text-sm">1 bedroom · 1 bed</p>

                <p className="font-semibold">
                  ₹{hotel.price.toLocaleString()}
                  <span className="font-normal text-gray-500"> / 3 nights</span>
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="w-[40%] p-4 rounded-lg h-full sticky top-0">
        {!isLoaded ? (
          <div className="flex items-center justify-center h-full">
            Loading Map...
          </div>
        ) : (
          <GoogleMap
            zoom={11}
            center={mapCenter}
            mapContainerClassName="w-full h-full rounded-2xl"
            onTilesLoaded={() => setTilesLoaded(true)}
            onClick={() => setSelectedHotel(null)}
          >
            {tilesLoaded &&
              hotels.map((hotel) => (
              <OverlayView
                  key={hotel.id}
                  position={{ lat: hotel.lat, lng: hotel.lng }}
                  mapPaneName={OverlayView.OVERLAY_MOUSE_TARGET}
                >
                  <div className="relative">
                    {/* PRICE */}
                    <div
                      onClick={(e) => handlePriceClick(e, hotel)}
                      className="pr-14 pl-3 py-1 rounded-full text-sm font-semibold shadow-lg cursor-pointer
                 bg-white text-black
                 -translate-x-1/2 -translate-y-1/2 transform"
                    >
                      ₹{hotel.price}
                    </div>

                    {/* MINI MODAL */}
                    {selectedHotel?.id === hotel.id && (
                      <div
                        onClick={(e) => {
                          e.stopPropagation();
                          e.preventDefault();
                          Navigate("/showhotel")

                        }}
                        className="absolute cursor-pointer left-1/2 bottom-full mb-2 w-56
                   -translate-x-1/2
                   bg-white rounded-xl shadow-xl p-3 z-50"
                      >
                        <img
                          src={hotel.image}
                          className="w-full h-28 object-cover rounded-lg"
                        />

                        <div className="mt-2">
                          <div className="flex justify-between items-center">
                            <h4 className="text-sm font-semibold line-clamp-1">
                              {hotel.name}
                            </h4>
                            <span className="text-xs">⭐ {hotel.rating}</span>
                          </div>

                          <p className="text-sm font-semibold mt-1">
                            ₹{hotel.price}
                            <span className="text-xs text-gray-500">
                              {" "}
                              / night
                            </span>
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </OverlayView>
              ))}
          </GoogleMap>
        )}
      </div>
    </div>
  );
};

export default Location;

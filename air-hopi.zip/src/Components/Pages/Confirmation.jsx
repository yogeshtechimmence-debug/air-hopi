import React from "react";

const Confirmation = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-10 px-4">
      <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-lg overflow-hidden">
        
        {/* Top Image */}
        <img
          src="https://images.unsplash.com/photo-1566073771259-6a8506099945"
          alt="Hotel"
          className="w-full h-56 object-cover"
        />

        {/* Content */}
        <div className="p-6 space-y-6">

          {/* Hotel Info */}
          <div>
            <h2 className="text-xl font-semibold">Hotel Royal Palace</h2>
            <p className="text-gray-500">
              Luxury stay in the heart of the city
            </p>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-4 border rounded-xl p-4">
            <div>
              <p className="text-sm text-gray-500">Check-in</p>
              <p className="font-medium">23 Jan 2026</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Check-out</p>
              <p className="font-medium">28 Jan 2026</p>
            </div>
          </div>

          {/* Guests */}
          <div className="border rounded-xl p-4">
            <p className="text-sm text-gray-500">Guests</p>
            <p className="font-medium">2 Adults · 1 Child</p>
          </div>

          {/* Special Request */}
          <div>
            <p className="text-sm text-gray-500 mb-1">Special Request</p>
            <textarea
              placeholder="Add any special requests (optional)"
              className="w-full border rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              rows={3}
            />
          </div>

          {/* Price */}
          <div className="flex justify-between items-center border-t pt-4">
            <p className="text-lg font-semibold">Total Price</p>
            <p className="text-2xl font-bold text-green-700">₹ 25,000</p>
          </div>

          {/* CTA Button */}
          <button className="w-full bg-green-700 hover:bg-green-800 text-white py-3 rounded-xl text-lg font-semibold">
            Continue & Pay
          </button>

        </div>
      </div>
    </div>
  );
};

export default Confirmation;

// import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
// import Location from "./Components/Pages/Location";
// import HomePage from "./Components/Pages/HomePage";
// import ShowHotel from "./Components/Pages/ShowHotel";
// import Footer from "./Components/Pages/Footer";
// import Navbar from "./Components/Pages/Navbar";
// import Bookings from "./Components/Pages/Bookings";
// import Favorites from "./Components/Pages/Favorites";
// import ProfilePage from "./Components/Pages/ProfilePage";
// import AboutUs from "./Components/Pages/AboutUs";

// function App() {
//   return (
//     <Router>
//       {/* Fixed Navbar */}
//       <Navbar />

//       {/* Page Content */}

//       <Routes>
//         <Route path="/" element={<HomePage />} />
//         <Route path="/location" element={<Location />} />
//         <Route path="/showhotel" element={<ShowHotel />} />
//         <Route path="/booking" element={<Bookings />} />
//         <Route path="/myfavorites" element={<Favorites />} />
//         <Route path="/profile" element={<ProfilePage />} />
//         <Route path="/about" element={<AboutUs />} />
//       </Routes>

//       {/* Footer always at bottom */}
//       <Footer />
//     </Router>
//   );
// }

// export default App;


import { Routes, Route, useLocation } from "react-router-dom";
import Location from "./Components/Pages/Location";
import HomePage from "./Components/Pages/HomePage";
import ShowHotel from "./Components/Pages/ShowHotel";
import Footer from "./Components/Pages/Footer";
import Navbar from "./Components/Pages/Navbar";
import Bookings from "./Components/Pages/Bookings";
import Favorites from "./Components/Pages/Favorites";
import ProfilePage from "./Components/Pages/ProfilePage";
import AboutUs from "./Components/Pages/AboutUs";
import Confirmation from "./Components/Pages/Confirmation";

const App = () => {
  const location = useLocation();

  const hideFooterRoutes = ["/booking", "/myfavorites", "/profile","/confirmation"];
  const hideFooter = hideFooterRoutes.includes(location.pathname);

  return (
    <>
      <Navbar />

      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/location" element={<Location />} />
        <Route path="/showhotel" element={<ShowHotel />} />
        <Route path="/booking" element={<Bookings />} />
        <Route path="/myfavorites" element={<Favorites />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/confirmation" element={<Confirmation />} />
      </Routes>

      {!hideFooter && <Footer />}
    </>
  );
};

export default App;

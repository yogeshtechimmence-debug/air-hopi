// GetCurrentLocation.jsx
import { useEffect, useState } from "react";
import useGoogleMaps from "./useGoogleMaps";

export default function GetCurrentLocation() {
  useGoogleMaps();  

  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [service, setService] = useState(null);

  // Initialize the old AutocompleteService when Google Maps is ready
  useEffect(() => {
    let interval = setInterval(() => {
      if (window.google && !service) {
        setService(new window.google.maps.places.AutocompleteService());
        clearInterval(interval);
      }
    }, 100);

    return () => clearInterval(interval);
  }, [service]);

  // Handle input changes
  const handleSearch = (value) => {
    setQuery(value);

    if (!value || !service) {
      setSuggestions([]);
      return;
    }

    service.getPlacePredictions(
      {
        input: value,
        componentRestrictions: { country: "in" }, // Only India
      },
      (predictions, status) => {
        if (status === window.google.maps.places.PlacesServiceStatus.OK) {
          setSuggestions(predictions || []);
        } else {
          setSuggestions([]);
          console.error("Autocomplete error:", status);
        }
      }
    );
  };

  // Get latitude & longitude from place_id
  const getLatLng = (placeId, description) => {
    const geocoder = new window.google.maps.Geocoder();

    geocoder.geocode({ placeId }, (results, status) => {
      if (status === "OK" && results[0]) {
        const location = results[0].geometry.location;
        console.log("Location:", description);
        console.log("Latitude:", location.lat());
        console.log("Longitude:", location.lng());

        setQuery(description);
        setSuggestions([]);
      } else {
        console.error("Geocode failed:", status);
      }
    });
  };

  return (
    <div className="relative w-full max-w-md">
      <input
        type="text"
        placeholder="Search any location in India..."
        value={query}
        onChange={(e) => handleSearch(e.target.value)}
        className="w-full border rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
      />

      {suggestions.length > 0 && (
        <ul className="absolute z-20 w-full bg-white border rounded-lg mt-1 shadow-lg max-h-60 overflow-auto">
          {suggestions.map((item) => (
            <li
              key={item.place_id}
              onClick={() => getLatLng(item.place_id, item.description)}
              className="px-4 py-2 cursor-pointer hover:bg-blue-50"
            >
              {item.description}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

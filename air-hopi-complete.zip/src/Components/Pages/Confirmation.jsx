import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import DatePicker from "react-datepicker";
import axios from "axios";
import "../Css/datepicker.css";
import StripeCheckout from "../Payment/StripeCheckout";
import { BASE_URL } from "../Base Url/ApiUrl";

const Confirmation = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const { placeDitails, startDate, endDate, guests } = state || {};
  // console.log(placeDitails)

  const [BookDate, setBookDate] = useState([]);
  const [guestCount, setGuestCount] = useState(guests || 1);

  const [checkIn, setCheckIn] = useState(
    startDate ? new Date(startDate) : null,
  );
  const [checkOut, setCheckOut] = useState(endDate ? new Date(endDate) : null);

  useEffect(() => {
    if (!placeDitails?.id) return;

    axios
      .get(`${BASE_URL}/get_booked_date_by_place`, {
        params: {
          place_id: placeDitails.id,
        },
      })
      .then((res) => {
        // console.log(res);
        setBookDate(res.data);
      })
      .catch((err) => {
        console.error("API ERROR:", err.response || err);
      });
  }, [placeDitails]);

  const disabledDates = (BookDate?.result || [])
    .filter((item) => item.availability_status === "No")
    .map((item) => new Date(item.booked_date));

  const isDateDisabled = (date) => {
    return disabledDates.some(
      (disabled) => disabled.toDateString() === date.toDateString(),
    );
  };

  const increaseGuests = () => {
    setGuestCount((prev) => prev + 1);
  };

  const decreaseGuests = () => {
    setGuestCount((prev) => (prev > 1 ? prev - 1 : 1));
  };

  const getTotalDays = () => {
    if (!checkIn || !checkOut) return 0;

    const diffTime = checkOut.getTime() - checkIn.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const totalDays = getTotalDays();

  const pricePerNight = Number(placeDitails?.rent_per_night);
  const totalAmount = totalDays * pricePerNight;

  let discountPercent = 0;

  if (totalDays > 30 && Number(placeDitails?.month_off) > 0) {
    discountPercent = Number(placeDitails.month_off);
  } else if (totalDays > 7 && Number(placeDitails?.week_off) > 0) {
    discountPercent = Number(placeDitails.week_off);
  }

  const discountAmount = Math.round((totalAmount * discountPercent) / 100);
  const finalPrice = totalAmount - discountAmount;

  // ---------------------------------------------- Booking Confirm ------------------------------

  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [successData, setSuccessData] = useState(null);

  const BookingConfirm = (stripeToken) => {
    const user_id = localStorage.getItem("user_id");
    const payload = new URLSearchParams();

    payload.append("user_id", user_id);
    payload.append("provider_id", placeDitails.provider_details.id);
    payload.append("place_id", placeDitails.id);

    payload.append("start_date", checkIn);
    payload.append("end_date", checkOut);
    payload.append("total_day", totalDays);

    payload.append("total_amount", finalPrice);
    payload.append("per_day_rate", placeDitails.rent_per_night);
    payload.append("requesttotalamount", finalPrice);
    payload.append("final_total", finalPrice);

    payload.append("no_of_guest", guestCount);

    payload.append("unique_code", "AIR" + Date.now());
    payload.append("provider_amount", placeDitails.provider_amount || 0);
    payload.append("admin_commission", "0");

    payload.append("payment_status", "Complete");
    payload.append("payment_type", "Card");
    payload.append("payment_id", stripeToken);

    payload.append("description", "Booking confirmed via Stripe");
    payload.append("offer_code", "");
    payload.append("offer_id", "");

    payload.append(
      "date_time",
      new Date().toISOString().slice(0, 19).replace("T", " "),
    );

    axios
      .post(`${BASE_URL}/add_place_booking`, payload, {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
      })
      .then((res) => {
        // console.log(res.data.result);

        setSuccessData({
          bookingId: res.data.result.id,
          totalAmount: res.data.result.total_amount,
        });

        setShowSuccessModal(true);
      })
      .catch((err) => console.error("BOOKING ERROR 👉", err));
  };

  const user_id = localStorage.getItem("user_id");

  return (
    <div className="min-h-screen bg-gray-50 py-10 px-4">
      <div className="max-w-6xl mx-auto bg-white shadow-lg rounded-2xl overflow-hidden flex flex-col lg:flex-row">
        {/* LEFT IMAGE */}
        <div className="w-full lg:w-1/2">
          <img
            src={placeDitails?.places_image[0]?.image}
            alt="Hotel"
            className="w-full h-64 lg:h-full object-cover"
          />
        </div>

        {/* RIGHT CONTENT */}
        <div className="w-full lg:w-1/2 p-6 lg:p-8 space-y-6">
          {/* Hotel Info */}
          <div>
            <h2 className="text-2xl font-semibold">Hotel Royal Palace</h2>
            <p className="text-gray-500">
              Luxury stay in the heart of the city
            </p>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-4 border rounded-xl p-4">
            {/* Check-in */}
            <div>
              <p className="text-sm text-gray-500">Check-in</p>

              <DatePicker
                selected={checkIn}
                onChange={(date) => {
                  setCheckIn(date);
                  setCheckOut(null);
                }}
                minDate={new Date()} // aaj se pehle disable
                filterDate={(date) => !isDateDisabled(date)}
                placeholderText="Select date"
                className="w-full font-medium outline-none cursor-pointer"
              />
            </div>

            {/* Check-out */}
            <div>
              <p className="text-sm text-gray-500">Check-out</p>

              <DatePicker
                selected={checkOut}
                onChange={(date) => setCheckOut(date)}
                minDate={checkIn}
                filterDate={(date) => {
                  if (!checkIn) return false;

                  let current = new Date(checkIn);

                  while (current <= date) {
                    if (isDateDisabled(current)) return false;
                    current.setDate(current.getDate() + 1);
                  }
                  return true;
                }}
                placeholderText="Select date"
                className="w-full font-medium outline-none cursor-pointer"
              />
            </div>
          </div>

          {/* Guests */}
          <div className="border rounded-xl p-4">
            <p className="text-sm text-gray-500">Guests</p>

            <div className="flex w-28 items-center justify-between mt-2">
              {/* Decrement */}
              <button
                onClick={decreaseGuests}
                className="w-8 h-8 rounded-full border flex items-center justify-center text-lg hover:bg-gray-100 disabled:opacity-40"
                disabled={guestCount <= 1}
              >
                −
              </button>

              {/* Count */}
              <p className="font-medium text-lg">{guestCount}</p>

              {/* Increment */}
              <button
                onClick={increaseGuests}
                className="w-8 h-8 rounded-full border flex items-center justify-center text-lg hover:bg-gray-100"
              >
                +
              </button>
            </div>
          </div>

          {/* Special Request */}
          <div>
            <p className="text-sm text-gray-500 mb-1">Special Request</p>
            <textarea
              placeholder="Add any special requests (optional)"
              className="
            w-full border rounded-xl p-3 text-sm
            focus:outline-none focus:ring-2 focus:ring-green-600
          "
              rows={3}
            />
          </div>

          {/* Price */}
          <div className="border-t pt-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span>
                ₹{pricePerNight} × {totalDays} nights
              </span>
              <span>₹{totalAmount}</span>
            </div>

            {discountPercent > 0 && discountAmount > 0 && (
              <div className="flex justify-between text-sm text-green-700">
                <span>{discountPercent}% long stay discount</span>
                <span>- ₹{discountAmount}</span>
              </div>
            )}

            <div className="flex justify-between text-lg font-semibold border-t pt-2">
              <span>Total</span>
              <span>₹{finalPrice}</span>
            </div>
          </div>

          {/* Stripe Payment */}
          <StripeCheckout
            finalPrice={finalPrice}
            userId={user_id}
            providerId={placeDitails.provider_details.id}
            placeId={placeDitails.id}
            onPaymentSuccess={BookingConfirm}
          />
        </div>
      </div>
      {showSuccessModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-8 rounded-xl shadow-lg text-center max-w-md w-full">
            <h2 className="text-2xl font-bold text-green-700">
              🎉 Booking Successful
            </h2>

            <p className="mt-2 text-gray-600">
              Your payment was successful via Stripe
            </p>

            <div className="mt-4 text-sm text-gray-700 space-y-1">
              <p>
                <b>Booking ID:</b> {successData?.bookingId}
              </p>
              <p>
                <b>Paid Amount:</b> ₹{successData?.totalAmount}
              </p>
            </div>

            <div className="mt-6 flex gap-3 justify-center">
              <button
                onClick={() => {
                  setShowSuccessModal(false);
                  navigate("/booking");
                }}
                className="bg-green-700 text-white px-6 py-2 rounded-lg"
              >
                View Bookings
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Confirmation;

// export const BASE_URL = "https://tenalpa-backend.onrender.com/tenalpa/admin";
export const BASE_URL = "https://techimmense.in/airhopi/webservice";

import { CardElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { useState } from "react";
import axios from "axios";

const StripeCheckout = ({
  finalPrice,
  userId,
  providerId,
  placeId,
  onPaymentSuccess,
}) => {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);

  const handlePayment = async () => {
    if (!stripe || !elements) return;
    setLoading(true);

    try {
      const { token, error } = await stripe.createToken(
        elements.getElement(CardElement),
      );

      console.log("TOKEN 👉", token);

      if (error) {
        alert(error.message);
        setLoading(false);
        return;
      }

      const payload = new URLSearchParams();
      payload.append("user_id", userId);
      payload.append("provider_id", providerId);
      payload.append("total_amount", finalPrice);
      payload.append("request_id", placeId);
      payload.append("payment_method", "CARD");
      payload.append("token", token.id);
      payload.append("currency", "INR");

      const res = await axios.post(
        "https://techimmense.in/airhopi/webservice/strip_payment",
        payload,
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        },
      );

      console.log("API RESPONSE 👉", res.data);

      if (res.data) {
        onPaymentSuccess(token.id);
      } else {
        alert("Payment failed");
      }
    } catch (err) {
      console.error("STRIPE ERROR 👉", err);
      alert("Payment error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <CardElement />
      <button
        onClick={handlePayment}
        disabled={loading}
        className="w-full bg-green-700 text-white py-3 rounded-xl"
      >
        {loading ? "Processing..." : `Pay ₹${finalPrice}`}
      </button>
    </div>
  );
};

export default StripeCheckout;

// export const BASE_URL = "https://tenalpa-backend.onrender.com/tenalpa/admin";
export const BASE_URL = "http://localhost:3000/loadlink";

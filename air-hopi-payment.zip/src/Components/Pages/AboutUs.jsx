import React from "react";

const AboutUs = () => {
  return (
    <div className="bg-gray-50">
      {/* HERO SECTION */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-16 text-center">
          <h1 className="text-4xl font-semibold mb-4">About Us</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            We help people find comfortable, affordable, and memorable stays —
            wherever life takes them.
          </p>
        </div>
      </div>

  
    </div>
  );
};

export default AboutUs;
